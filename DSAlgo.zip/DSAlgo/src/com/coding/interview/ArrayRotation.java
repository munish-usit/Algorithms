/*HackerRank -> Cracking the Coding Interview -> https://www.hackerrank.com/challenges/ctci-array-left-rotation */

package com.coding.interview;

import java.util.Scanner;

public class ArrayRotation {
	public static int[] arrayLeftRotation1(int[] a, int n, int k) {
		int [] temp = new int[k];
		for(int i=0;i<k;i++) {
			temp[i] = a[i];
		}
		int j;
		for(j=0;j+k<n;j++){
			a[j] = a[j+k];
		}
		for(int i=0;i<temp.length;i++){
			a[j] = temp[i];
			j++;
		}
		return a;
	}
	
	public static int[] arrayLeftRotation2(int[] a,int n, int k) {
		int [] b = new int[n];
		for(int i=0;i<n;i++) {
			b[i] = a[(i-(n-k)+n)%n];
		}
		return b;
		
	}

	public static void main(String[] args) {
		System.out.println("Enter input");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int k = in.nextInt();
		int a[] = new int[n];
		for(int a_i=0; a_i < n; a_i++){
			a[a_i] = in.nextInt();
		}
		int[] output = new int[n];
		//output = arrayLeftRotation1(a, n, k);
		output = arrayLeftRotation2(a, n, k);
		
		for(int i = 0; i < n; i++)
			System.out.print(output[i] + " ");

		System.out.println();

	}
}
