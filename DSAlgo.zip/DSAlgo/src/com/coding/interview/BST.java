  package com.coding.interview;

import java.util.LinkedList;
import java.util.Queue;


public class BST {
	private Node root;
	
	private class Node {
		private int data;
		private Node left;
		private Node right;
		Node(int data) {
			this.data = data;
			this.left = this.right = null;
			
		}
		
	}
	
	public BST() {
		root = null;
	}
	public Node getRoot() {
		return root;
	}
	public int getRootData() {
		return root.data;
	}
	public void insert(int value) {
		root = insert(root,value);
	}
	// recursive call
	private Node insert(Node node,int value) {
		if(node == null) {
			node = new Node(value);
		} else if(value <= node.data) {
			node.left = insert(node.left,value);
		} else {
			node.right = insert(node.right,value);
		}
		return node;
		
	}
	public int findMin() {
		if(root == null) return -1;
		Node current = root;
		while(current.left != null) {
			current = current.left;
		}
		return current.data;
	}
	public int findMax() {
		if(root == null) return -1;
		Node current = root;
		while(current.right != null) {
			current = current.right;
		}
		return current.data;
	}
	public int height() {
		return height(root);
	}
	private int height(Node node) {
		if(node == null) return -1;
		else return 1+Math.max(height(node.left),height(node.right));
	}
	public boolean search(int value) {
		return search(root,value);
	}
	private boolean search(Node node,int value) {
		if(node == null) return false;
		else if (node.data == value) return true;
		else if (value < node.data ) return search(node.left,value);
		else return search(node.right,value);
		
	}
	public void BFSTraversal() {
		 Queue<Node> q = new LinkedList<Node>();
		 q.add(root);
		 while(!q.isEmpty()) {
			 Node current = q.poll();
			 System.out.print(current.data+" ");
			 if(current.left != null ) q.add(current.left);
			 if(current.right != null ) q.add(current.right);
		 }
	}
	public void delete(int value) {
		root = delete(root,value);
	}
	private Node delete(Node node,int value) {
		if(null == node) return null;
		else if (value < node.data) node.left = delete(node.left,value);
		else if (value > node.data) node.right = delete(node.right,value);
		// we have found the node to be deleted
		else {
			// case 1 no children
			if(node.left == null && node.right == null) return null;
			//case 2 single child
			else if (node.left == null) return node.right;
			else if (node.right == null) return node.left;
			// case 3 2 children
			else {
				int minRightSubTree = findMinNode(node.right);
				node.data = minRightSubTree;
				node.right = delete(node.right,minRightSubTree);
			}
		}
		return node;
	}
	private int findMinNode(Node node) {
		while(node.left != null) {
			node = node.left;
		}
		return node.data;
	}
	public boolean isBST() {
		return isBST(root,Integer.MIN_VALUE,Integer.MAX_VALUE);
	}
	private boolean isBST(Node node,int minValue,int maxValue) {
		if(root == null) return true;
		else if(node.data > minValue && node.data < maxValue
				&& isBST(node.left,minValue,node.data)
				&& isBST(node.right,node.data,maxValue)
				) {
			return true;
		}
		else return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BST bt = new BST();
		bt.insert(20);
		bt.insert(16);
		bt.insert(34);
		bt.insert(5);
		bt.insert(18);
		bt.insert(54);
		bt.insert(8);
		bt.insert(30);
		System.out.println("Root data ::"+bt.getRootData());
		System.out.println("BST Max ::"+bt.findMax());
		System.out.println("BST Min ::"+bt.findMin());
		System.out.println("BST height ::"+bt.height());
		System.out.println("BST value exist ::"+bt.search(34));
		bt.BFSTraversal();
		bt.delete(18);
		System.out.println("After deletion");
		bt.BFSTraversal();
	}

}
