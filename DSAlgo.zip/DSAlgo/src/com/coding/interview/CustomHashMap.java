package com.coding.interview;

public class CustomHashMap<K,V> {
	private Entry<K,V> [] table;
	private int DEFAULT_CAPACITY = 16;
	
	static class Entry<K,V> {
		private K key;
		private V value;
		private Entry<K,V> next;
		
		Entry(K key, V val, Entry<K,V> next) {
			this.key = key;
			this.value = val;
			this.next = next;
		}
				
	}
	@SuppressWarnings("unchecked")
	CustomHashMap() {
		table = new Entry[DEFAULT_CAPACITY];
	}
	public int hash(K key) {
		
		int hash =  Math.abs(key.hashCode()%DEFAULT_CAPACITY);
		System.out.println("Key:Hash :: "+key+":"+hash);
		return hash;
				
	}
	// put(2,3);
	public V put(K key, V value) {
		Entry<K, V> newEntry = new Entry<K, V>(key, value, null);
		int hash = hash(key);
		if(key == null) hash = 0; //null key insert at 0 bucket/location
		if(table[hash] == null) {
			table[hash] = newEntry; // first entry in bucket
			return null;
		}
		Entry<K,V> prev = null;
		Entry<K,V> current = table[hash];
		while(current != null) {
			if(key.equals(current.key) || key == (current.key)) {
				// if same key then we just update the value;
				V oldValue = current.value;
				current.value = value;
				return oldValue;
			}
			prev = current;
			current = current.next;
		}
		prev.next = newEntry;
		return null;
		
	}
	public V get(K key) {
		
		int hash = hash(key);
		if(key == null) hash = 0; //null key insert at 0 bucket/location
		Entry<K,V> current = table[hash];
		while(current != null) {
			if(key.equals(current.key) || key == (current.key)) {
				// if same key then we just update the value;
				return current.value;
				
			}
			current = current.next;
		}
		return null;
		
	}
	
	 public void display(){
	       
	       for(int i=0;i<DEFAULT_CAPACITY;i++){
	           if(table[i]!=null){
	                  Entry<K, V> entry=table[i];
	                  while(entry!=null){
	                        System.out.print("{"+entry.key+"="+entry.value+"}" +" ");
	                        entry=entry.next;
	                  }
	           }
	       }             
	    
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 CustomHashMap<Integer, Integer> hashMapCustom = new CustomHashMap<Integer, Integer>();
         hashMapCustom.put(21, 12);
         hashMapCustom.put(25, 121);
         hashMapCustom.put(30, 151);
         hashMapCustom.put(33, 15);
         hashMapCustom.put(35, 89);
         hashMapCustom.put(21, 89);
         hashMapCustom.put(21, 121);


         System.out.println("value corresponding to key 21="
                      + hashMapCustom.get(21));
         System.out.println("value corresponding to key 51="
                      + hashMapCustom.get(51));
         
         System.out.print("Displaying : ");
         hashMapCustom.display();


	}

}
