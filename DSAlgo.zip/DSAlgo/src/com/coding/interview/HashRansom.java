package com.coding.interview;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashRansom {
	Map<String, Integer> magazineMap;
	Map<String, Integer> noteMap;
	public HashRansom(String magazine,String note){
		magazineMap = new HashMap<String, Integer>();
		noteMap = new HashMap<String, Integer>();
		String[] a1 = magazine.split(" ");
		String[] a2 = note.split(" ");
		for(int i=0;i<a1.length;i++){
			if(magazineMap.containsKey(a1[i])) {
				magazineMap.put(a1[i], magazineMap.get(a1[i])+1);
			}else{
				magazineMap.put(a1[i],1);
			}
		}
		for(int i=0;i<a2.length;i++){
			if(noteMap.containsKey(a2[i])) {
				noteMap.put(a2[i], noteMap.get(a2[i])+1);
			}else{
				noteMap.put(a2[i],1);
			}
		}
	}
	public boolean solve(){
		boolean result = false;
		for(String word:noteMap.keySet()){
			if(magazineMap.containsKey(word) && (magazineMap.get(word) >= noteMap.get(word))){
				result = true;
			} else {
				result = false;
				break;
			}
		}
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        int m = scanner.nextInt();
        int n = scanner.nextInt();
        
        // Eat whitespace to beginning of next line
        scanner.nextLine();
        
        HashRansom s = new HashRansom(scanner.nextLine(), scanner.nextLine());
        scanner.close();  
        
        boolean answer = s.solve();
        if(answer)
            System.out.println("Yes");
        else System.out.println("No");

	}

}
