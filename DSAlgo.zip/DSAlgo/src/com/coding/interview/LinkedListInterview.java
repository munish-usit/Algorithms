package com.coding.interview;
import com.customds.CustomLinkedList;
public class LinkedListInterview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomLinkedList list = new CustomLinkedList();
		list.add(20);
		list.add(40);
		list.add(60);
		list.add(80);
		list.display();
	}

}
