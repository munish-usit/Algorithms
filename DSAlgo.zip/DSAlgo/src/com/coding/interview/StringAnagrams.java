package com.coding.interview;

import java.util.HashMap;
import java.util.Scanner;

public class StringAnagrams {
	
	public static int NUMBER_LETTERS = 26;
	public static int numberNeeded(String first, String second) {
		HashMap<Character, Integer> h1 = new HashMap<Character, Integer>();
		HashMap<Character, Integer> h2 = new HashMap<Character, Integer>();
		for(int i=0;i<first.length();i++) {
			char ch = first.charAt(i);
			if(h1.containsKey(ch)) {
				h1.put(ch, h1.get(ch)+1);
			}else {
				h1.put(ch, 1);
			}
		}
		for(int i=0;i<second.length();i++) {
			char ch = second.charAt(i);
			if(h2.containsKey(ch)) {
				h2.put(ch, h2.get(ch)+1);
			}else {
				h2.put(ch, 1);
			}
		}
		int numberNeeed = 0;
		for(Character ch : h1.keySet()){
			if(h2.containsKey(ch)) {
				int temp = h1.get(ch) - h2.get(ch);
				numberNeeed += Math.abs(temp);
			}
			else {
				numberNeeed += h1.get(ch);
			}
		}
		for(Character ch : h2.keySet()){
			if(!h1.containsKey(ch)) {
				numberNeeed += h2.get(ch);
			}
			
		}
		
		return numberNeeed;
	      
    }
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String a = in.next();
		String b = in.next();
		//System.out.println(numberNeeded(a, b));
		System.out.println(numberNeeded2(a, b));
		
	}
	
	public static int numberNeeded2(String first, String second) {
		int [] count1 = getOccurences(first);
		int [] count2 = getOccurences(second);
		int numberNeed = getDelta(count1,count2);
		
		return numberNeed;
	      
    }
	public static int[] getOccurences(String s) {
		int array[] = new int[NUMBER_LETTERS];
		for(int i=0;i<s.length();i++){
			int index = s.charAt(i) - 'a';
			array[index]++;
		}
		return array;
	}
	public static int getDelta(int[] array1,int[] array2){
		int result = 0;
		for(int i=0;i<array1.length;i++){
			int diff = array1[i] - array2[i];
			result = result + Math.abs(diff);
		}
		return result;
	}

}
