/**
 * 
 */
/**
 * @author smunish
 * The questions solved are from HackerRank -> Cracking the Coding Interview(book)
 * https://www.hackerrank.com/domains/tutorials/cracking-the-coding-interview
 *
 */
package com.coding.interview;