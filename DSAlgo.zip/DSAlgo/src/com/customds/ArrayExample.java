package com.customds;

import java.util.Arrays;


public class ArrayExample {
	
	public static final int CAPACITY = 20;
	public static int count = 0;
	
	public static void main(String [] args) {
		
		int [] array = new int[CAPACITY];
		array[0] = 40;array[1]=45;array[2]=50;
		count = 3;
		insert(array,0,10);
		insert(array,1,20);
		insert(array,2,30);
		insert(array,1,15);
		
		System.out.println(Arrays.toString(array));
		
		delete(array,6);
		delete(array,5);
		
		System.out.println(Arrays.toString(array));
		
		System.out.println("total elements : "+count);
		
		binarySearch(array,40);
		binarySearch(array,60);
		
		
		reverseArray(array);
		System.out.println(Arrays.toString(array));
		
	}
	
	//Insert element in array
	
	public static void insert(int [] array,int index,int key) {
		
		if(count >= CAPACITY || index >= CAPACITY || index <0) return;
		
		
		for(int i = count-1;i>=index;i--) {
			array[i+1] = array[i];
		}
		array[index] = key;
		count +=1;
		
	}
	
	public static void delete(int[] array,int index) {
		
		if(count <0 || index >=CAPACITY || index < 0) return;
		
		int value = array[index];
		for(int i = index; i<count; i++) {
			array[i] = array[i+1];
		}
		count = count -1;
		System.out.println("Element Deleted :"+value);
	}
	
	public static void binarySearch(int [] array,int value) {
		
		int first = 0;
		int last = count - 1;
		int middle = 0;
		boolean found = false;
		int loc=0;
		while(first <= last && !found) {
			
			middle = (first+last)/2;
			
			if(value == array[middle]) {
				found = true;
				loc = middle;
			}else if(value < array[middle]){
				last = middle-1;
			}else {
				first = middle+1;
			}
		}
		if(found) System.out.println("Value Found at "+loc+" position");
	}
	
	public static void reverseArray(int [] array) {
		
		int start = 0;
		int end = count - 1;
		
		while(start <end) {
			/*array[start] = array[start]+array[end];
			array[end] = array[start] - array[end];
			array[start] = array[start] - array[end];*/
			// swapping using XOR operator
			array[start] = array[start]^array[end];
			array[end] = array[start]^array[end];
			array[start] = array[start]^array[end];
			start++;
			end--;
		}
		
	}
	
	
	

}
