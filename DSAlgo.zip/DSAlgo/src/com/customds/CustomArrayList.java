package com.customds;



public class CustomArrayList {

	private static final int CAPACITY = 6;
	private Object[] array; 
	private int count;
	CustomArrayList() {
		array = new Object[CAPACITY];
		count = 0;
	}
	public void insert(int index, Object element) {
		if(index <0 ) {
			System.out.println("Invalid index !!");
			return;
		}
		else if(count == array.length) {
			System.out.println("inside ensue capacity");
			ensureCapacity();
		}
		{
			for(int k = count-1;k>=index;k--) {
				array[k+1] = array[k];
			}
			array[index]= element;
			count++;
			//System.out.println("Element Inserted :"+temp.toString());
		}
	}
	public void insert(int element) {
		insert(count,element);
	}
	private void ensureCapacity() {
		Object [] newData = new Object[2*CAPACITY];
		for(int i=0;i<count;i++){
			newData[i] = array[i];
		}
		array = newData;
	}
	public void delete(int index) {
		if(count == 0 || index < 0|| index >=count) {
			System.out.println("Not possible Invalid !!");
			return;
		}else {
			Object temp = array[index];
			for(int k = index; k<count-1;k++) {
				array[k] = array[k+1];
			}
			count--;
			System.out.println("Element Deleted :"+temp.toString());
		}
	}
	public void display() {
		String output = "";
		for(int i=0;i<count;i++) {
			if(output.length()>0) output += ",";
			output += array[i].toString();
		}
		System.out.println(output);
		System.out.println("Size::"+count);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomArrayList list= new CustomArrayList();
		list.insert(10);
		list.insert(20);
		list.insert(30);
		list.insert(50);
		list.insert(60);
		list.insert(70);
		list.display(); //10 20 30 50 60 70
		list.delete(4);
		list.insert(2,25); // 10 20 25 30 50 70
		list.display();
		System.out.println("ensure capacity test");
		list.insert(80);
		list.display();
	}

}
