package com.customds;


public class CustomLinkedList {
	
	private Node head;
	
	private static int count = 0;
	
	private class Node {
		private int data;
		private Node next;
		Node(int data) {
			this.data = data;
			this.next = null;		
		}
	}
	
	public CustomLinkedList() {
		head = null;
		
	}
	
	public void add(int index,int value) {
		if(index < 0 || index > count) {
			System.out.println("Invalid index !!");
			return;
		}
		//valid index
		Node temp = new Node(value);
		if(index == 0) {
			temp.next = head;
			head = temp;
		} else {
			Node current = head;
			for(int i=0;i<index -1;i++) {
				current = current.next;
			}
			//current points to index-1 node
			temp.next = current.next;
			current.next = temp;
		}
		count++;
		System.out.println("Element inserted : "+value+ " Total elements : "+count);
		
	}
	public void add(int value) {
		add(count,value);
	}
	public void removeAt(int index) {
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		if(index < 0 || index >= count) {
			System.out.println("Invalid index !!");
			return;
		}
		//valid index
		Node temp = null;
		if(index == 0) {
			temp = head;
			head = head.next;
			temp.next = null;
		} else {
			Node current = head;
			for(int i=0;i<index -1;i++) {
				current = current.next;
				
			}
			//current points to index-1 node
			temp = current.next; //temp points to index node ie node to be deleted
			current.next = temp.next;
			temp.next = null;
			
		}
		count--;
		if(temp != null) System.out.println("Element removed : "+temp.data+ " Total elements : "+count);
	}
	public void remove(int value) {
		// logic is same for remove and removeAt..
		// just storing current and prev in different way
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		Node current = head;
		Node prev = null;
		while(current != null && current.data != value) {
			prev = current;
			current = current.next;
			
		}
		if(current != null) { // we have found the value to be deleted
			if(current == head) { //first node to be deleted
				head = head.next;
				current.next = null;
			} else {
				prev.next = current.next;
				current.next = null;
			}
			count --;
			System.out.println("Element removed : "+current.data+ " Total elements : "+count);
		} else { // not found 
			System.out.println("Value not found");
		}
		
	}
	public void display(){
		Node current = head;
		while(current != null) {
			System.out.print(current.data+" ");
			current = current.next;
		} 
		System.out.println();
	}
	public void displayForwardRecursion() {
		displayForwardRecursion(head);
	}
	// print list through recursion
	private void displayForwardRecursion(Node temp) {
		if(temp == null) return;
		System.out.print(temp.data+" ");
		displayForwardRecursion(temp.next);
	}
	public void displayReverseRecursion() {
		displayReverseRecursion(head);
	}
	private void displayReverseRecursion(Node temp) {
		if(temp == null) return;
		displayReverseRecursion(temp.next);
		System.out.print(temp.data+" ");
		
	}
	public void reverse() {
		Node current = head;
		Node prev = null;
		while(current != null) {
			Node temp = current.next;
			current.next = prev;
			prev = current;
			current = temp;
		}
		head = prev;
	}
	public void reverseRecursion() {
		reverseRecursion(head);
	}
	// reverse list through recursion method
	// recursion method allow us to traverse list in backward direction
	private void reverseRecursion(Node ptr) {
		if(ptr.next == null) { // to identify last node
			head = ptr;
			return;
		}
		reverseRecursion(ptr.next);
		ptr.next.next = ptr;
		ptr.next = null;
		
	}
	// compare two list by passing list head 
	int CompareLists(CustomLinkedList listA, CustomLinkedList listB) {
		Node headA = listA.head;
		Node headB = listB.head;
	    int result = 0;
	    while(headA != null && headB != null) {
	        if(headA.data != headB.data) {
	            result = 0;
	            break;
	        }
	        headA = headA.next;
	        headB = headB.next;
	    }
	    if(headA == headB) result = 1;
	    return result;
	}
	// Get nth node value from tail
	// https://www.geeksforgeeks.org/nth-node-from-the-end-of-a-linked-list/
	// Method 1 if index start from 0 the nth index from tail = (count-1-n)
	// Method 2 Use 2 pointers main and ref.Initially ref points to index position and main points to head.Move pointer one by one until ref pointer reaches null, main pointer will reach the required location.
	void displayNodeFromTail(int index) {
		if(head == null) return;
		if(index <0 || index >=count) return;
		// Method 1
		/*
		int startIndex = (count-1-index);
		Node ptr = head;
		for(int i=0; i<startIndex;i++) ptr = ptr.next;
		if(ptr != null) System.out.println("Value at index "+index+" from tail is "+ptr.data);
		*/
		
		//Method 2
		Node main = head;
		Node temp = head;
		for(int i=0;i<index;i++) temp = temp.next;
		
		while(temp.next != null) {
			main = main.next;
			temp = temp.next;
		}
		if(main != null) System.out.println("Value at index "+index+" from tail is "+main.data);
			
	}
	void removeDuplicates() {
		if(head == null ) {
			System.out.println("Empty list");
			return;
		}
		Node current = head;
		while(current.next != null) {
			if(current.data == current.next.data) {
				Node temp = current.next;
				current.next = temp.next;
				temp.next = null;
				count --;
				System.out.println("Removing duplicate : "+temp.data+" total size :"+count);
			}
			else current = current.next;
		}
	}
	public static void main(String[] args) {
		CustomLinkedList list = new CustomLinkedList();
	
		list.add(20);
		list.add(40);
		list.add(60);
		list.add(80);
		list.add(0,10);
		list.add(2,30);
		list.add(90);
		list.display();
		list.removeAt(-1);
		list.removeAt(6);
		list.remove(30);
		list.add(80);
		list.add(0,10);
		list.add(4,60);
		list.display();
		//list.reverse();
		//System.out.println("After reverse");
		//list.display();
		//list.displayForwardRecursion();
		//System.out.println("\nReverse display recurssion");
		//list.displayReverseRecursion();
		//list.reverseRecursion();
		//System.out.println("Afrer reverse recursion");
		//list.display();
		list.displayNodeFromTail(4);
		list.removeDuplicates();
		list.display();
		
					
	}

}
