package com.customds;

public class CustomStack {

	private static int CAPACITY = 2;
	private int top ;
	private int [] stack; 
	public CustomStack() {
		top = -1;
		stack = new int[CAPACITY];
	}
	public void push(int element){
		if(top == CAPACITY -1) {
			System.out.println("Stack full");
			ensureCapacity();
			//return;
		}
		stack[++top] = element;
	}
	public void ensureCapacity() {
		CAPACITY = 2*CAPACITY;
		int temp [] = new int[CAPACITY];
		for(int i =0;i<stack.length;i++) {
			temp[i] = stack[i];
		}
		stack = temp;
		
	}
	public void pop() {
		if(top == -1) {
			System.out.println("Stack is Empty !!");
			
		} else {
			int elem = stack[top];
			top--;
			System.out.println("Element pop = "+elem);
		}
	}
	int top () {
		System.out.println("Current Element:"+stack[top]);
		return stack[top];
	}
	public boolean isEmpty() {
		return (top == -1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomStack s = new CustomStack();
		s.push(10);
		s.push(20);
		s.push(30);
		s.top();
		s.pop();
		s.top();
		s.pop();
		s.top();
		s.pop();
		s.pop();
	}

}
