package com.customds;

/* Stack implementation through Linked List */

public class CustomStackList {

	private class Node {
		int data;
		Node next;
		Node(int data) {
			this.data = data;
			this.next = null;
		}
	}
	Node top;
	CustomStackList() {
		top = null;
	}
	public void push(int element) {
		Node temp = new Node(element);
		temp.next = top;
		top = temp;
	}
	public void pop() {
		if(top == null) {
			System.out.println("Stack Empty");
			return;
		}
		Node temp = top;
		top = top.next;
		System.out.println("Element removed:"+temp.data);
		temp.next = null;
		
	}
	public int top() {
		System.out.println("Current Element:"+top.data);
		return top.data;
	}
	public boolean isEmpty () {
		return (top == null);
	}
	public static void main(String[] args) {
		CustomStackList s = new CustomStackList();
		s.push(10);
		s.push(20);
		s.push(30);
		s.top();
		s.pop();
		s.top();
		s.pop();
		s.top();
		s.pop();
		s.pop();
	}
}
