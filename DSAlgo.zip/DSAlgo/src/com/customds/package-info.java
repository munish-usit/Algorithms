/**
 * 
 */
/**
 * @author smunish
 * Liner data structures linked list and array implementation in java
 * Reference to youtube channerl code my school
 *
 */
package com.customds;