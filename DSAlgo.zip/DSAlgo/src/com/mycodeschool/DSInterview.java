package com.mycodeschool;

import java.util.Stack;

public class DSInterview {

	// Check for balanced parenthesis
	// https://www.hackerrank.com/challenges/balanced-brackets/problem
	public  boolean isBalancedParenthesis(String exp) {
		Stack<Character> st = new Stack<Character>();
		for(int i=0;i<exp.length();i++) {
			char ch = exp.charAt(i);
			if(ch == '{' || ch == '(' || ch == '[') {
				st.push(ch);
			} else if(ch == '}' || ch == ')' || ch == ']') {
				if(st.isEmpty()) return false;
				else if(!isMatchingPair(st.pop(),ch)) return false;
			}
		}
		if(st.isEmpty()) return true;
		else return false;
	}
	public boolean isMatchingPair(char ch1, char ch2) {
		if(ch1 == '{' && ch2 == '}') return true;
		else if(ch1 == '(' && ch2 == ')') return true;
		else if(ch1 == '[' && ch2 == ']') return true;
		else return false;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DSInterview ds = new DSInterview();
		String test = ")(";
		System.out.println("Balanced Paranthesis :: "+ds.isBalancedParenthesis(test));
	}

}
