/**
 * 
 */
/**
 * @author smunish
 * Programming question under Data structure topic in youtube channel mycodeschool
 *
 */
package com.mycodeschool;