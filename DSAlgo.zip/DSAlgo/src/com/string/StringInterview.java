package com.string;

public class StringInterview {
	
	/*	Function return the longest unique(without repeating char) substring 
	 *	https://stackoverflow.com/questions/9734474/find-longest-substring-without-repeating-characters 
	 */
	public static String longestUniqueString(String input) {
		String output = "";
		String tempString = "";
		for(int i =0; i<input.length();i++) {
			char ch = input.charAt(i);
			// space "" is added for comparison of char with string api
			if(tempString.contains(""+ch)) {
				tempString = tempString.substring(tempString.indexOf(ch)+1);
			}
			tempString = tempString + ch;
			if(tempString.length() > output.length()) {
				output = tempString;
			}
		}
		return output;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringInterview obj = new StringInterview();
		System.out.println("Longest Unique String :"+obj.longestUniqueString("geeksforgeeks"));

	}

}
