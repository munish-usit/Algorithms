/**
 * 
 */
/**
 * @author smunish
 * The class contains string related coding interview questions
 *
 */
package com.string;