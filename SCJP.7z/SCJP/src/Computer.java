/* Class refers to top level class not the nested or inner class
 * Class level access modifier (public and default only)
 * Class can't be private or protected as they are useless outside their class declaration
 * A source code file can have only 1 public class and multiple non-public(default) classes.
 * If source code file have public class then name of file = name of public class.
 * If source code file doesn't have public class then name of file can be anything.
 * Each class public or default can have their respective main methods.
 * Each class will have their respective .class file in destination folder. (.class file name = class name)
  */

public class Computer {

	public void printComputer() {
		System.out.println("Hello Computer");
	}
	/*public static void main(String [] args) {
		
		System.out.println("Hello Main");
		Computer cmp = new Computer();
		cmp.printComputer();
		Laptop lap = new Laptop();
		lap.printLaptop();
		Printer prnt = new Printer();
		prnt.printPrinter();
		
	}*/
}

class Laptop {
	
	public void printLaptop() {
		
		System.out.println("Hello Laptop");
	}
	public static void main(String [] args) {
		
		System.out.println("Hello Main");
		Laptop lap = new Laptop();
		lap.printLaptop();
		Computer cmp = new Computer();
		cmp.printComputer();
		Printer prnt = new Printer();
		prnt.printPrinter();
	}
}

class Printer {
	
	public void printPrinter() {
		
		System.out.println("Hello Printer");
	}
	public static void main(String [] args) {
		
		System.out.println("Hello Main");
		Printer prnt = new Printer();
		prnt.printPrinter();
		Computer cmp = new Computer();
		cmp.printComputer();
		Laptop lap = new Laptop();
		lap.printLaptop();
	}
}