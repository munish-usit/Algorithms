/* Array works on both primitive and reference variable. Memory is always alocated on heap.
 * Size of array is determined when JVM allocates memory to array on heap. Size can't change after that.
 * int [10] marks is wrong.. as JVM determine size during memory allocation onlye ie when you use new operator.
 * int [] marks = new int[10]; correct
 * Array indexes are itself behave like reference variable a[0], a[1]
 * */

package com.package1;

public class ArrayExample {

	public static void main(String [] args) {
		
	 int [] marks = new int[10];
	 int [] rollnos = {1,2,3,4};
	 String [] names = new String[] {"Rahul","Akash","Sachin","Saurav"};
	 marks[0] = 90;
	 marks[1] = 98;
	 marks[2] = 100;
	 marks[3] = 96;
	 System.out.println("Marks length : "+marks.length);
	 System.out.println("Rollno length :"+rollnos.length);
	 System.out.println("Names length :"+names.length);
	 
	}
}
