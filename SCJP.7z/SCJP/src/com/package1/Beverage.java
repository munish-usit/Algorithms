/* Default level class is not accessible outside the package. It means as if the class doesn't exist outside the package.
 * Accessible means can't create instance, reference, extend the class. Method can't return reference or instance.
 * Can't event import the default level class outside the package. "import com.package2.Tea" will give compile time error but "import comp.package2.*" is valid.
 * In this example remove public access level of class Tea to see compile time errors.
 * */
package com.package1;
import com.package2.*;
public class Beverage {
	
	public void printBeverage() {
		
		System.out.println("Hello Beverage");
	}
	

	public static void main (String [] args) {
		
		System.out.println("Hello Main");
		Beverage b = new Beverage();
		b.printBeverage();
		//Tea t = new Tea();
		//t.printTea();
	}
	
	/*public Tea giveTea() {
		
		return new Tea();
	}*/
}
