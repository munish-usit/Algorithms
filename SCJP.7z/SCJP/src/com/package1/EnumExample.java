/* Enum allow variable to have one value out of list. Very useful in scenarios where a variable can have only specific value.
 * Eg enum Color {RED,BLUE,GREEN} enum WorkDays {MON,TUE,WED,THU,FRI}
 * enum is equivalent to class having public static final variable ie class having constants. Enum can be used in replacement of constant class
 * enum is similar to class and can have constructor, methods and instance variables.
 * enum can be declared like a class(private,protected) or it can be a member of class
 * With constructor and instance variable we can associate some property to enum values like for each workday there can be workday color.
 * */
package com.package1;

enum Workday {
	MONDAY("Red"),
	TUESDAY("Blue"),
	WEDNESDAY("Green"),
	THURSDAY("Black"),
	FRIDAY("White");
	
	private String workdayColor;
	
	Workday(String workdayColor) {
		this.workdayColor = workdayColor;
	}
	
	public String getWorkdayColor() {
		return workdayColor;
	}
	
}
class Schedule {
 private Workday workday;
 public Workday getWorkday() {
	 return workday;
 }
 public void setWorkday(Workday workday) {
	 this.workday = workday;
 }
	
}
public class EnumExample {

	public static void main(String [] args) {
		
		for(Workday w : Workday.values()) {
			System.out.println("Workday : "+w.name());
			System.out.println("Workday Color : "+w.getWorkdayColor());
		}
		
		Schedule s = new Schedule();
		s.setWorkday(Workday.FRIDAY);
		System.out.println("Current Workday : "+s.getWorkday().name());
		System.out.println("Current Workday Color : "+s.getWorkday().getWorkdayColor());
	}
}
