/* Parent Class is declared as Public.
 * Child class is present outside the  same package and is accessing member through inheritance and using reference(dot operator)
 * Inheritance --> public,protected members are inherited but private and default members are not inherited.
 * Reference --> public member is  accessible but private,default and protected members are not accessible
 */

package com.package2;
import com.package3.Parent;

public class Child extends Parent {

	public void checkInheritanceVisibility() {
		 
		//System.out.println("Roll no "+rollno); //default member not inherited by class outside the package
		System.out.println("Name "+name); 
		//System.out.println("Marks "+marks); // private member can't be inherited
		System.out.println("Rank "+rank);
		
	}
	public static void main(String [] args) {
		
		Parent p = new Parent();
		//System.out.println("Roll no "+p.rollno); // default member not accessible by class outside the package
		System.out.println("Name "+p.name);
		//System.out.println("Marks "+p.marks); // private not accessible outside the class
		//System.out.println("Rank "+p.rank); // protected not accessible(using dot) by class outside the package
		Child c = new Child();
		c.checkInheritanceVisibility();
	}
}
