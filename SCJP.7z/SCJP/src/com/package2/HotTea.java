public class HotTea
{

public static void main(String [] args) {

System.out.println("Hello HotTea");

}
}