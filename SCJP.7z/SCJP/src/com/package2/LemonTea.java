/* Default access level classes are accessible inside the same package.
 * If we declare main method without string args then it will be treated as normal method whose name is "main"
 * There will be no compile time error but you can't run the class as JVM will give "main method not found" error
 * 
 * */
package com.package2;

public class LemonTea {

	public void printLemonTea() {
		
		System.out.println("Hello LemonTea");
	}
	public static void main(String[] args) {
	 System.out.println("Hello Main");
	 LemonTea lt = new LemonTea();
	 lt.printLemonTea();
	 Tea t = new Tea();
	 t.printTea();
	}
	public Tea giveTea() {
		
		return new Tea();
	}
}
