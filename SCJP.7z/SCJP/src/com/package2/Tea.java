/* How to run classes inside some package.
 * Tea class will have its full name as com.package2.Tea after compilation
 * Run java com.package2.Tea  . Make sure you are outside of this package location ie com.package2
 * JVM by default look for class in current path and package location. 
 * Compile javac Tea.java
 * package apply to class only with statement "package com.package2";
 * */
package com.package2;

 class Tea {

public void printTea() {
		
		System.out.println("Hello Tea");
	}
	

	public static void main (String [] args) {
		
		System.out.println("Hello Main");
		Tea t = new Tea();
		t.printTea();
	}
}
