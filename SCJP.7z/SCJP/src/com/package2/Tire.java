package com.package2;

import com.package3.Bounceable;

public class Tire implements Bounceable{

	int factor = FACTOR;
	@Override
	public void bounce() {
		// TODO Auto-generated method stub
		System.out.println("Tire is bouncing by factor "+factor);
	}

	@Override
	public void setBounceFactor(int factor) {
		// TODO Auto-generated method stub
		this.factor = factor;
	}

}
