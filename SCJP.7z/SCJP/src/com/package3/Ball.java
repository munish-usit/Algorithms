package com.package3;

public class Ball implements Bounceable {

	int factor = FACTOR;
	@Override
	public void bounce() {
		// TODO Auto-generated method stub
		System.out.println("Ball is bouncing by factor "+factor);
	}

	@Override
	public void setBounceFactor(int factor) {
		// TODO Auto-generated method stub
		this.factor = factor;
	}

}
