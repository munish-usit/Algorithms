/* Interface is 100% abstraction. It doesn't have inheritance relationship. Two diff class can implement the same interface.
 * Class implementing the interface means the class on which you can invoke the interface methods.
 * Interface is by default (implicitly) abstract
 * Interface methods are by default (implicitly) public and abstract
 * Interface variables are by default (implicitly) public,static and final ie CONSTANTS
 * Interface methods can't be static ie can't be class level.
 * */



package com.package3;

public interface Bounceable {

	int FACTOR = 20;
	void bounce();
	void setBounceFactor(int factor);
	
}
