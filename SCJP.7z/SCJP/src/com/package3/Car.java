/*
 * Example of Abstract Car.
 * Abstract class is similar to normal class. It can have method and instance variable with different modifier (private,static etc).
 * Abstract and Final modifier are mutually exclusive. They don't go simultaneously.
 * Abstract class can have constructor, main method and can be executed just like a normal class
 * If any of the method is declared as abstract then class is also declared as abstract.
 * The only diff b/w normal and abstract class is that abstract class can't be instantiated directly.
 * Constructor of abstract class is called during object chaining (inheritance).
 * Abstract class can have those instance variable which are common to all the sub classes.
 * Abstract class can have those non-abstract methods whose implementation doesn't change with inheritance ie methods common to all subclasses eg getter and setter. 
 * Methods whose implementation changes with inheritance are declared as abstract.
 * With methods declared as abstract there is guarantee that sub class will override them.
 * Methods marked as abstract must ends with semicolon and vice-versa.
 * Methods ending with empty curly braces means that methods have implementation but no implementation is given.
 * 
 *  */
package com.package3;

public abstract class Car {

	Car() {
		System.out.println("Hello Abstract Constructor");
	}
	private double price; // these instance variables are included because every car will have these properties.
	private String year;
	private String model;
	public abstract void goFast(); // these methods are declared as abstract because their implementation will change with inheritance.(diff type of car)
	public abstract void goUpHill();
	public abstract void impressNeighbors();
	public static void main(String[] args) {
		
		System.out.println("Hello Abstract Class");
	}
}
