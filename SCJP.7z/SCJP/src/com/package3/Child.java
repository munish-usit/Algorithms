/* Parent Class is declared as Public.
 * Child class is present in same package and is accessing member through inheritance and using reference(dot operator)
 * Inheritance --> public,default and protected members are inherited but private member is not inherited.
 * Reference --> public, default and protected members are accessible but private member is not accessible
 * Final method is inherited but can't be overriden
 */
package com.package3;

public class Child extends Parent {

	public void checkInheritanceVisibility() {
	 
		rollno = 24;
		name = "Munish Sharma";
		rank = 3;
		//teacherName = "Sonali"; // can't change value of final variable
		System.out.println("Roll no "+rollno);
		System.out.println("Name "+name);
		//System.out.println("Marks "+marks); // private member can't be inherited
		System.out.println("Rank "+rank);
		printHello(); // final method is inherited but can't be overriden.
		
	}
	public static void main(String [] args) {
		
		Parent p = new Parent();
		p.rollno = 26;
		p.name = "Sagar";
		p.rank = 2;
		System.out.println("Roll no "+p.rollno);
		System.out.println("Name "+p.name);
		//System.out.println("Marks "+p.marks); // private not accessible outside the class
		System.out.println("Rank "+p.rank);
		Child c = new Child();
		c.checkInheritanceVisibility();
	}
}
