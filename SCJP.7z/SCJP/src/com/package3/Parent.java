/*	Accessibility									Public			Default			Protected			Private
 *	Within same class								Y				Y				Y					Y 
 * 	Class inside same package(dot)					Y				Y				Y					N
 * 	Subclass inside same package(inherited)			Y				Y				Y					N
 * 	Class outside same package(dot)					Y				N				N					N
 * 	Subclass outside same package(inherited)		Y				N				Y					N
 * 
 */


package com.package3;

public class Parent {

	int rollno = 16;
	public String name = "Gajender";
	private int marks = 100;
	protected int rank = 1;
	final public String teacherName = "Vivek";
	
	public final void printHello() {
		System.out.println("Hello printHello");
	}
}
